# Initialise modes as a package

from modes.checkpointMode import checkpointMode
from modes.nonCheckpointMode import nonCheckpointMode